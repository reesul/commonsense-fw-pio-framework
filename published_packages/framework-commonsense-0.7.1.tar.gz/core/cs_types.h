#pragma once


 enum return_status_t {
    STATUS_OK = 0,
    STATUS_ERR = 1
} cs_return_status_t;
/*************************
 * 
 *  CommonSense Firmware
 * 
 * ***********************/

#pragma once

#include <sam.h>

//Definitions

//Framework includes
#include "pinMap.h"
#include "pinConfig.h"
#include "led.h"

